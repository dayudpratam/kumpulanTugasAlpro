// ADT  : Book
// NAME : Dwi Yuda Pratama
// DATE : Saturday,20 mei 2023
#include <iostream>
#include <string>
#include <string.h>
#include "Book.h"
using namespace std;


// Main function
int main() {

    int n; // Number of books to input

    cout << "Berapa banyak buku yang ingin anda masukan? ";
    cin >> n;

    Book books[n]; // Declare an array of books

    // Input each book information from user
    for (int i = 0; i < n; i++) {

        string name, author;
        int year;

        cout << "Masukan Judul Buku " << i+1 << ": ";
        cin.ignore();
        getline(cin, name);

        cout << "Masukan Nama Pengarang Buku " << i+1 << ": ";
        getline(cin, author);

        cout << "Masukan Tahun Terbit Buku " << i+1 << ": ";
        cin >> year;

        books[i] = Book(name, author, year); // Create a new book object and assign it to the array

        cout << endl;

    }

    char choice; // Choice to continue or end program

    do {

        int option; // Option to choose search function

        cout << "Pilih salah satu pilihan yang ada:\n";
        cout << "1. Mencari data menggunakan Judul\n";
        cout << "2. Mencari data menggunakan Nama Pengarang\n";
        cout << "3. Mencari data  menggunakan Tahun Terbit\n";
        cout << "4. Menampilkan semua Data\n";

        cin >> option;

        switch(option) {

            case 1: { // Search by name

                string target; // Target name to search

                cout << "Masukan Judul Buku untuk mencari: ";
                cin.ignore();
                getline(cin, target);

                int result = searchByName(books, n, target); // Call search by name function

                if (result != -1) { // If found

                    cout << "Buku ditemukan:\n";
                    books[result].display(); // Display found book

                } else { // If not found

                    cout << "Buku tidak ditemukan.\n";

                }

                break;

            }

            case 2: { // Search by author

                string target; // Target author to search

                cout << "Masukan Nama Pengarang untuk mencari: ";
                cin.ignore();
                getline(cin, target);

                int result = searchByAuthor(books, n, target); // Call search by author function

                if (result != -1) { // If found

                    cout << "Buku ditemukan:\n";
                    books[result].display(); // Display found book

                } else { // If not found

                    cout << "Buku tidak ditemukan.\n";

                }

                break;

            }

            case 3: { // Search by year

                int target; // Target year to search

                cout << "Masukan Tahun untuk mencari: ";
                cin >> target;

                int result = searchByYear(books, n, target); // Call search by year function

                if (result != -1) { // If found

                    cout << "Buku ditemukan:\n";
                    books[result].display(); // Display found book

                } else { // If not found

                    cout << "Buku tidak ditemukan.\n";

                }

                break;

            }

            case 4: { // Display all data

                displayAllBooks(books, n); // memanggil display all books function

                break;

            }

            default: { // Invalid option

                cout << "Opsi tidak valid.\n";

            }

        }

        cout << "\nApakah  ingin bertanya lagi? Y/N ";

        cin >> choice;

    } while (choice == 'Y' || choice == 'y');

    return 0;
}
